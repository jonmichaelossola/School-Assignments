/***************************************************************
 * File: product.h
 * Author: (your name here)
 * Purpose: Contains the definition of the Product class
 ***************************************************************/
#ifndef PRODUCT_H
#define PRODUCT_H
#include <string>
#include <iostream>
using namespace std;

// put your class definition here
class Product
{
	private:
		string name;
		double price;
		double weight;
		string description;
		int option;

	public:
		void prompt();
		void displayAdvertising() const;
		void displayInventory() const;
		void displayReceipt() const;
		double getSalesTax() const;
		double getShippingCost() const;
		double getTotalPrice() const;
};
#endif
